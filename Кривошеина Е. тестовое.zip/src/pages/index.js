import css from '../pages/index.css';

// прокрутка страницы и привязка header
const header = document.querySelector('.header');

function scrollMonitoring(event) {
    event.preventDefault();
  
    if (event.deltaY < 0) {
      header.classList.add('header_sticky');
    }
    else {
      header.classList.remove('header_sticky');
    }
}
  
document.onwheel = scrollMonitoring;
window.addEventListener('wheel', scrollMonitoring);

// появление блока покупок
const products = document.querySelector('.products');
const buyBlock = document.querySelector('.buy-tablo');
const buyLink = buyBlock.querySelector('.link_buy');

function scrollBuy(event) {
    event.preventDefault();
  
    if (event.deltaY > 0) {
      buyBlock.classList.add('buy-tablo_sticky');
    }
    else {
      buyBlock.classList.remove('buy-tablo_sticky');
    }
}
  
document.onwheel = scrollBuy;
products.addEventListener('wheel', scrollBuy);

function clickBuyButton() {
  buyBlock.classList.remove('buy-tablo_sticky');
}

buyLink.addEventListener('click', clickBuyButton);